class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.ultralytics.nn.modules.___torch_mangle_656.Bottleneck
  __annotations__["1"] = __torch__.ultralytics.nn.modules.___torch_mangle_663.Bottleneck
  __annotations__["2"] = __torch__.ultralytics.nn.modules.___torch_mangle_670.Bottleneck
  __annotations__["3"] = __torch__.ultralytics.nn.modules.___torch_mangle_677.Bottleneck
