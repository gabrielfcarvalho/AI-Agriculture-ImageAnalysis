class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.ultralytics.nn.modules.___torch_mangle_727.Bottleneck
  __annotations__["1"] = __torch__.ultralytics.nn.modules.___torch_mangle_734.Bottleneck
