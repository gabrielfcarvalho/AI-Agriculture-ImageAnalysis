class SPPF(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.___torch_mangle_707.Conv
  cv2 : __torch__.ultralytics.nn.modules.___torch_mangle_710.Conv
  m : __torch__.torch.nn.modules.pooling.___torch_mangle_711.MaxPool2d
  def forward(self: __torch__.ultralytics.nn.modules.___torch_mangle_712.SPPF,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_858.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    cv1 = self.cv1
    _0 = (cv1).forward(argument_1, argument_2, )
    _1 = (m).forward(_0, )
    _2 = (m).forward1(_1, )
    input = torch.cat([_0, _1, _2, (m).forward2(_2, )], 1)
    return (cv2).forward(argument_1, input, )
